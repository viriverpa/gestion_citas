from django.urls import path
from . import views

urlpatterns = [
    path('', views.landing, name='landing'),
    # path('especialista/', views.panel_especialista, name='panel_especialista'),  👈🏻 Comentamos esta línea por ahora
    path('paciente/', views.panel_paciente, name='panel_paciente'),
    path('cita/<int:cita_id>/atendida/', views.marcar_cita_atendida, name='marcar_cita_atendida'),
    path('historia/<int:paciente_id>/', views.ver_historia, name='ver_historia'),
    path('panel/', views.landing_admin, name='landing_admin'),
]
