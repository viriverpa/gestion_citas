def landing(request):
    if request.method == 'GET':
        logout(request)  # Limpia cualquier sesión previa SOLO al cargar el formulario

    form = LoginForm()

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            documento = form.cleaned_data['documento']
            password = form.cleaned_data['password']
            rol = form.cleaned_data['rol']

            user = authenticate(username=documento, password=password)

            if user is not None:
                login(request, user)
                return redirect('/panel/')  # 🔥 Redirige directamente por URL
            else:
                form.add_error(None, 'Documento o contraseña incorrectos.')

    return render(request, 'web/landing.html', {'form': form})
