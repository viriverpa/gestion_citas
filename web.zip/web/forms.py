from django import forms

class LoginForm(forms.Form):
    ROL_CHOICES = [
        ('especialista', 'Especialista'),
        ('paciente', 'Paciente'),
    ]

    rol = forms.ChoiceField(
        choices=ROL_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    documento = forms.CharField(
        max_length=10,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Número de identificación'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Contraseña'})
    )
